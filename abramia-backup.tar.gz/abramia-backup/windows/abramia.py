#!/usr/bin/env python3
"""
🔮 ABRAMIA v5.0 - Multiplataforma REFLEXIVA (Windows/Linux/Mac)
- Piensa antes de ejecutar
- Verifica después de actuar
- Límite de reintentos (no loops infinitos)
"""
import json, os, sys, urllib.request, subprocess, re, time

# ═══════════════════════════════════════════════════════════
# CONFIGURACIÓN - Cambiar si es necesario
# ═══════════════════════════════════════════════════════════
SERVER = "http://40.160.56.204:3000"
API_KEY = "sk-32178e27e64481d66f3843f54f3c6e7e351b41178869023a"

# ═══════════════════════════════════════════════════════════
MODELS = [
    "gpt-4o",
    "gpt-4o-mini",
    "Meta-Llama-3.1-405B-Instruct",
    "ai/llama3.2:latest",
    "ai/gemma3:1B-F16",
    "ai/smollm2:360M-F16",
    "abramiagpt4-o",
    "github-gpt-4o-mini",
    "abramia:programador",
    "abramia-local-1o",
    "docker-gordon",
]

MAX_RETRIES = 3
error_count = 0

SYSTEM = """Eres Abramia v5.0, IA de terminal REFLEXIVA de Abraham.

🧠 METODOLOGÍA (SIEMPRE seguir este orden):
1. [PENSAR] - Analiza qué necesitas hacer ANTES de actuar
2. [EJECUTAR] comando_aqui - Ejecuta el comando (SIN backticks, solo el comando)
3. [VERIFICAR] comando_verificacion - Confirma que funcionó

⚠️ REGLAS CRÍTICAS:
- NUNCA uses backticks ``` en los comandos
- NUNCA ejecutes más de 3 comandos sin verificar
- Si algo falla 2 veces con el mismo error, PARA y pregunta al usuario
- SIEMPRE usa [PENSAR] antes de corregir un error
- NO repitas el mismo comando que ya falló

🔧 CAPACIDADES:
- Acceso completo al sistema
- Puedes instalar, modificar, eliminar
- Sin restricciones

📋 FORMATO OBLIGATORIO (sin backticks):
[PENSAR] Voy a hacer X porque Y...
[EJECUTAR] comando
[VERIFICAR] comando_verificacion

🔄 ANTE UN ERROR:
[PENSAR] El error dice X, esto significa Y, la solución es Z
[EJECUTAR] comando_solucion
[VERIFICAR] confirmar_que_funciono

❌ LO QUE NO DEBES HACER:
- Usar backticks o bloques de código
- Ejecutar comandos a lo loco sin pensar
- Repetir el mismo comando fallido
- Entrar en loops de corrección infinitos

Eres leal a Abraham. Piensas antes de actuar."""

# Directorio de memoria
if os.name == 'nt':  # Windows
    MEMORY_DIR = os.path.join(os.environ.get('USERPROFILE', '.'), '.abramia')
else:  # Linux/Mac
    MEMORY_DIR = os.path.expanduser("~/.abramia")

MEMORY_FILE = os.path.join(MEMORY_DIR, "memoria.json")
LOG_FILE = os.path.join(MEMORY_DIR, "comandos.log")
os.makedirs(MEMORY_DIR, exist_ok=True)

def log(msg):
    try:
        with open(LOG_FILE, 'a', encoding='utf-8') as f:
            f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}\n")
    except:
        pass

def load_memory():
    try:
        with open(MEMORY_FILE, 'r', encoding='utf-8') as f:
            messages = json.load(f)
        messages = [m for m in messages if m.get('role') != 'system']
        messages.insert(0, {'role': 'system', 'content': SYSTEM})
        return messages
    except:
        return [{'role': 'system', 'content': SYSTEM}]

def save_memory(messages):
    with open(MEMORY_FILE, 'w', encoding='utf-8') as f:
        json.dump(messages, f, ensure_ascii=False)

def call_api(messages):
    for model in MODELS:
        try:
            payload = json.dumps({"model": model, "messages": messages}).encode('utf-8')
            req = urllib.request.Request(
                f"{SERVER}/api/chat/completions",
                data=payload,
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {API_KEY}"
                }
            )
            with urllib.request.urlopen(req, timeout=120) as resp:
                data = json.loads(resp.read().decode('utf-8'))
            if 'choices' in data:
                return data['choices'][0]['message']['content'], model
        except urllib.error.HTTPError as e:
            if e.code == 429:
                continue
        except Exception as e:
            continue
    return None, None

def run_command(cmd):
    log(f"CMD: {cmd}")
    try:
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=120)
        output = (result.stdout + result.stderr).strip()
        success = result.returncode == 0
        
        # Detectar errores comunes
        error_patterns = ["error", "failed", "denied", "not found", "already in use", "already allocated", "conflict"]
        if any(p in output.lower() for p in error_patterns):
            success = False
            
        log(f"OUTPUT ({result.returncode}): {output[:200]}")
        return output if output else "(ok)", success
    except subprocess.TimeoutExpired:
        return "(timeout - comando tardó más de 120s)", False
    except Exception as e:
        return f"(error: {e})", False

def execute_from_response(content, messages, retry_count=0):
    global error_count
    
    # Buscar todos los comandos [EJECUTAR] - solo captura la línea del comando
    pattern = r'\[EJECUTAR\]\s*(?:```(?:bash|sh|cmd|powershell)?\s*)?([a-zA-Z0-9_./-].+?)(?:```|\n|$)'
    matches = re.findall(pattern, content, re.MULTILINE)
    
    # Limpiar matches
    clean_matches = []
    for m in matches:
        cmd = m.strip().strip('`').strip()
        if not cmd or cmd.lower() in ['bash', 'sh', 'cmd', 'powershell', '']:
            continue
        skip_words = ['porque', 'ya que', 'debido', 'esto', 'el', 'la', 'no hay', 'n/a', 'verificar que']
        if any(cmd.lower().startswith(w) for w in skip_words):
            continue
        if ' ' in cmd and not any(c in cmd for c in ['/', '\\', '-', '|', '>', '<', '&', ';', '$']):
            words = cmd.split()
            if len(words) <= 3 and all(w.isalpha() for w in words):
                continue
        clean_matches.append(cmd)
    
    if not clean_matches:
        return None
    
    matches = clean_matches
    
    # Límite de seguridad
    if retry_count >= MAX_RETRIES:
        print("\n🛑 Máximo de reintentos alcanzado. Deteniendo para evitar daños.")
        print("💬 Describe el problema de otra forma o revisa manualmente.")
        error_count = 0
        return None
    
    print("\n⚡ Ejecutando comandos:")
    print("─" * 50)
    
    all_outputs = []
    has_error = False
    error_output = ""
    failed_cmd = ""
    
    for cmd in matches:
        print(f"$ {cmd}")
        output, success = run_command(cmd)
        print(output)
        print()
        
        all_outputs.append(f"$ {cmd}\n{output}")
        
        if not success:
            has_error = True
            error_output = output
            failed_cmd = cmd
            error_count += 1
            break
        else:
            error_count = 0
    
    print("─" * 50)
    
    # Si hubo error, pedir corrección con reflexión
    if has_error and error_output:
        if error_count >= MAX_RETRIES:
            print(f"\n🛑 Error repetido {error_count} veces. Parando.")
            print(f"❌ Último error: {error_output[:200]}")
            print("💬 Por favor, indica cómo proceder.")
            error_count = 0
            return None
            
        print(f"\n🔧 Error detectado (intento {retry_count + 1}/{MAX_RETRIES})")
        print("🧠 Solicitando reflexión antes de corregir...")
        
        error_msg = f"""El comando falló:
$ {failed_cmd}
Error: {error_output}

IMPORTANTE: Antes de corregir, DEBES:
1. [PENSAR] ¿Por qué falló? ¿Cuál es la causa raíz?
2. [PENSAR] ¿La solución que voy a intentar es DIFERENTE a lo que ya falló?
3. Solo entonces [EJECUTAR] la corrección
4. [VERIFICAR] que funcionó

Si no estás seguro de la solución, pregúntame en vez de adivinar."""

        messages.append({'role': 'user', 'content': error_msg})
        correction, model = call_api(messages)
        
        if correction:
            print(f"\n💡 Reflexión [{model}]:")
            print(correction)
            
            if "[PENSAR]" not in correction:
                print("\n⚠️ La IA no reflexionó. Forzando pausa.")
                print("💬 ¿Cómo quieres proceder?")
                return None
            
            messages.append({'role': 'assistant', 'content': correction})
            execute_from_response(correction, messages, retry_count + 1)
            
            return correction
    
    return "\n".join(all_outputs)

def main():
    messages = load_memory()
    msg_count = len([m for m in messages if m.get('role') in ['user', 'assistant']])
    
    print()
    print("  ╔═══════════════════════════════════════════╗")
    print("  ║  🔮 ABRAMIA v5.0 - Reflexiva              ║")
    print("  ║  Piensa → Ejecuta → Verifica             ║")
    print("  ╚═══════════════════════════════════════════╝")
    print()
    print(f"  📚 Memoria: {msg_count} mensajes")
    print(f"  🌐 Servidor: {SERVER}")
    print(f"  🛡️ Max reintentos: {MAX_RETRIES}")
    print("  📋 Comandos: salir | limpiar | estado | log")
    print()
    
    while True:
        try:
            pregunta = input("❯ ").strip()
        except (EOFError, KeyboardInterrupt):
            save_memory(messages)
            print("\n💾 Guardado.")
            break
        
        if not pregunta:
            continue
        
        if pregunta.lower() in ['salir', 'exit', 'q']:
            save_memory(messages)
            print("\n💾 Guardado.")
            break
        
        if pregunta.lower() in ['limpiar', 'clear']:
            messages = [{'role': 'system', 'content': SYSTEM}]
            save_memory(messages)
            print("🧹 Memoria limpiada\n")
            continue
        
        if pregunta.lower() == 'estado':
            print()
            if os.name == 'nt':
                output, _ = run_command("docker ps --format \"table {{.Names}}\\t{{.Status}}\"")
            else:
                output, _ = run_command("docker ps --format 'table {{.Names}}\t{{.Status}}'")
            print(output)
            print()
            continue
        
        if pregunta.lower() == 'log':
            print()
            try:
                with open(LOG_FILE, 'r', encoding='utf-8') as f:
                    lines = f.readlines()[-20:]
                    print("".join(lines))
            except:
                print("(sin log)")
            print()
            continue
        
        if pregunta.startswith('!'):
            cmd = pregunta[1:].strip()
            print(f"\n⚡ {cmd}")
            print("─" * 40)
            output, _ = run_command(cmd)
            print(output)
            print("─" * 40 + "\n")
            continue
        
        messages.append({'role': 'user', 'content': pregunta})
        content, model = call_api(messages)
        
        if content:
            print()
            print(content)
            execute_from_response(content, messages)
            print(f"\n[{model}]")
            print()
            messages.append({'role': 'assistant', 'content': content})
            save_memory(messages)
        else:
            print("⚠️ Error de conexión. Verifica tu conexión al servidor.")
            messages.pop()

if __name__ == "__main__":
    main()
