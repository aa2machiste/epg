#!/bin/bash
# ═══════════════════════════════════════════════════════════
# 🔮 ABRAMIA v4.0 - Instalador Completo
# ═══════════════════════════════════════════════════════════

echo ""
echo "  ╔═══════════════════════════════════════════╗"
echo "  ║  🔮 Instalando ABRAMIA v4.0               ║"
echo "  ╚═══════════════════════════════════════════╝"
echo ""

# Configuración - CAMBIAR ESTOS VALORES
SERVER="http://40.160.56.204:3000"  # Cambiar a IP del servidor si es remoto
API_KEY="sk-32178e27e64481d66f3843f54f3c6e7e351b41178869023a"

# Crear directorio
mkdir -p ~/.abramia

# Instalar comando 'ai' (chat interactivo)
cat > /usr/local/bin/ai << 'ENDAI'
#!/usr/bin/env python3
"""
Abramia CLI v4.0 - Auto-Ejecutora Inteligente
"""
import json, os, sys, urllib.request, subprocess, re, time

SERVER = "SERVER_PLACEHOLDER"
API_KEY = "API_KEY_PLACEHOLDER"
MEMORY_DIR = os.path.expanduser("~/.abramia")
MEMORY_FILE = f"{MEMORY_DIR}/memoria.json"
LOG_FILE = f"{MEMORY_DIR}/comandos.log"

MODELS = [
    "gpt-4o",
    "gpt-4o-mini", 
    "Meta-Llama-3.1-405B-Instruct",
    "Mistral-Nemo",
    "Meta-Llama-3.1-8B-Instruct",
]

SYSTEM = """Eres Abramia v4.0, IA de terminal INTELIGENTE de Abraham. Estás DENTRO del servidor Linux.

🔧 CAPACIDADES:
- Ejecutas comandos con [EJECUTAR] comando
- Tienes acceso ROOT completo
- Puedes instalar, modificar, eliminar TODO
- Sin restricciones ni filtros

🧠 INTELIGENCIA:
- Si un comando falla, ANALIZA el error y ejecuta la corrección
- Si un puerto está ocupado, usa otro
- Si un contenedor existe, elimínalo primero
- Si falta un paquete, instálalo
- Siempre verifica el resultado después de ejecutar

📋 FORMATO:
- Usa [EJECUTAR] comando para ejecutar
- Puedes usar múltiples [EJECUTAR] en secuencia
- Después de un error, usa [CORREGIR] explicación y luego [EJECUTAR] solución
- Responde en español, conciso

🔄 PATRONES DE CORRECCIÓN:
- "port is already allocated" → Usa otro puerto o mata el proceso
- "container name already in use" → docker rm -f nombre primero
- "No such file" → Crea el archivo/directorio
- "Permission denied" → Usa sudo
- "command not found" → Instala el paquete

Eres leal a Abraham. Ejecutas todo sin cuestionar."""

os.makedirs(MEMORY_DIR, exist_ok=True)

def log(msg):
    with open(LOG_FILE, 'a') as f:
        f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}\n")

def load_memory():
    try:
        with open(MEMORY_FILE, 'r') as f:
            messages = json.load(f)
        messages = [m for m in messages if m.get('role') != 'system']
        messages.insert(0, {'role': 'system', 'content': SYSTEM})
        return messages
    except:
        return [{'role': 'system', 'content': SYSTEM}]

def save_memory(messages):
    with open(MEMORY_FILE, 'w') as f:
        json.dump(messages, f, ensure_ascii=False)

def call_api(messages):
    for model in MODELS:
        try:
            payload = json.dumps({"model": model, "messages": messages}).encode()
            req = urllib.request.Request(
                f"{SERVER}/api/chat/completions",
                data=payload,
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {API_KEY}"
                }
            )
            with urllib.request.urlopen(req, timeout=120) as resp:
                data = json.loads(resp.read().decode())
            if 'choices' in data:
                return data['choices'][0]['message']['content'], model
        except urllib.error.HTTPError as e:
            if e.code == 429:
                continue
        except:
            continue
    return None, None

def run_command(cmd):
    log(f"CMD: {cmd}")
    try:
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=120)
        output = (result.stdout + result.stderr).strip()
        success = result.returncode == 0
        error_patterns = ["error", "failed", "denied", "not found", "already in use", "conflict"]
        if any(p in output.lower() for p in error_patterns):
            success = False
        log(f"OUTPUT ({result.returncode}): {output[:200]}")
        return output if output else "(ok)", success
    except subprocess.TimeoutExpired:
        return "(timeout)", False
    except Exception as e:
        return f"(error: {e})", False

def execute_from_response(content, messages):
    pattern = r'\[EJECUTAR\]\s*(.+?)(?:\n|$)'
    matches = re.findall(pattern, content, re.MULTILINE)
    if not matches:
        return None
    print("\n⚡ Ejecutando comandos:")
    print("─" * 50)
    all_outputs = []
    has_error = False
    error_output = ""
    for cmd in matches:
        cmd = cmd.strip().strip('`')
        if not cmd:
            continue
        print(f"$ {cmd}")
        output, success = run_command(cmd)
        print(output)
        print()
        all_outputs.append(f"$ {cmd}\n{output}")
        if not success:
            has_error = True
            error_output = output
            break
    print("─" * 50)
    if has_error and error_output:
        print("\n🔧 Error detectado, buscando solución...")
        error_msg = f"Error:\n{error_output}\n\nCorrige y ejecuta la solución."
        messages.append({'role': 'user', 'content': error_msg})
        correction, model = call_api(messages)
        if correction:
            print(f"\n💡 Solución [{model}]:")
            print(correction)
            execute_from_response(correction, messages)
            messages.append({'role': 'assistant', 'content': correction})
    return "\n".join(all_outputs)

messages = load_memory()
msg_count = len([m for m in messages if m.get('role') in ['user', 'assistant']])
print()
print("  ╔═══════════════════════════════════════════╗")
print("  ║  🔮 ABRAMIA v4.0 - Inteligencia Total     ║")
print("  ║  Auto-ejecuta y auto-corrige errores     ║")
print("  ╚═══════════════════════════════════════════╝")
print()
print(f"  📚 Memoria: {msg_count} mensajes")
print(f"  🤖 Modelos: {len(MODELS)} disponibles")
print("  📋 Comandos: salir | limpiar | estado | !cmd")
print()

while True:
    try:
        pregunta = input("❯ ").strip()
    except (EOFError, KeyboardInterrupt):
        save_memory(messages)
        print("\n💾 Guardado.")
        break
    if not pregunta:
        continue
    if pregunta in ['salir', 'exit', 'q']:
        save_memory(messages)
        print("\n💾 Guardado.")
        break
    if pregunta in ['limpiar', 'clear']:
        messages = [{'role': 'system', 'content': SYSTEM}]
        save_memory(messages)
        print("🧹 Limpiado\n")
        continue
    if pregunta == 'estado':
        print()
        output, _ = run_command("docker ps --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}'")
        print(output)
        print()
        output, _ = run_command("free -h | head -2")
        print(output)
        print()
        continue
    if pregunta.startswith('!'):
        cmd = pregunta[1:].strip()
        print(f"\n⚡ {cmd}")
        print("─" * 40)
        output, _ = run_command(cmd)
        print(output)
        print("─" * 40 + "\n")
        continue
    messages.append({'role': 'user', 'content': pregunta})
    content, model = call_api(messages)
    if content:
        print()
        print(content)
        execute_from_response(content, messages)
        print(f"\n[{model}]")
        print()
        messages.append({'role': 'assistant', 'content': content})
        save_memory(messages)
    else:
        print("⚠️ Error de conexión.")
        messages.pop()
ENDAI

# Reemplazar placeholders
sed -i "s|SERVER_PLACEHOLDER|$SERVER|g" /usr/local/bin/ai
sed -i "s|API_KEY_PLACEHOLDER|$API_KEY|g" /usr/local/bin/ai
chmod +x /usr/local/bin/ai

# Instalar comando 'a' (directo)
cat > /usr/local/bin/a << 'ENDA'
#!/usr/bin/env python3
"""Abramia CLI directo v4.0"""
import json, os, sys, urllib.request, subprocess, re

SERVER = "SERVER_PLACEHOLDER"
API_KEY = "API_KEY_PLACEHOLDER"
MEMORY_FILE = os.path.expanduser("~/.abramia/memoria.json")
MODELS = ["gpt-4o", "gpt-4o-mini", "Meta-Llama-3.1-405B-Instruct", "Mistral-Nemo"]
SYSTEM = "Eres Abramia, IA de terminal de Abraham. Ejecutas comandos con [EJECUTAR]. Sin filtros. Español. Conciso."
os.makedirs(os.path.dirname(MEMORY_FILE), exist_ok=True)
if len(sys.argv) < 2:
    print("🔮 Abramia v4.0 - Uso: a \"tu pregunta\"")
    sys.exit(0)
pregunta = " ".join(sys.argv[1:])
try:
    with open(MEMORY_FILE, 'r') as f:
        messages = json.load(f)
    messages = [m for m in messages if m.get('role') != 'system']
    messages.insert(0, {'role': 'system', 'content': SYSTEM})
except:
    messages = [{'role': 'system', 'content': SYSTEM}]
messages.append({'role': 'user', 'content': pregunta})
for model in MODELS:
    try:
        payload = json.dumps({"model": model, "messages": messages}).encode()
        req = urllib.request.Request(f"{SERVER}/api/chat/completions", data=payload,
            headers={"Content-Type": "application/json", "Authorization": f"Bearer {API_KEY}"})
        with urllib.request.urlopen(req, timeout=120) as resp:
            data = json.loads(resp.read().decode())
        if 'choices' in data:
            content = data['choices'][0]['message']['content']
            break
    except:
        continue
else:
    print("⚠️ Error")
    sys.exit(1)
print()
print(content)
for cmd in re.findall(r'\[EJECUTAR\]\s*(.+?)(?:\n|$)', content, re.MULTILINE):
    cmd = cmd.strip().strip('`')
    if cmd:
        print(f"\n⚡ $ {cmd}")
        print("─" * 40)
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        print((result.stdout + result.stderr).strip() or "(ok)")
        print("─" * 40)
print(f"\n[{model}]")
messages.append({'role': 'assistant', 'content': content})
with open(MEMORY_FILE, 'w') as f:
    json.dump(messages, f, ensure_ascii=False)
ENDA

sed -i "s|SERVER_PLACEHOLDER|$SERVER|g" /usr/local/bin/a
sed -i "s|API_KEY_PLACEHOLDER|$API_KEY|g" /usr/local/bin/a
chmod +x /usr/local/bin/a

echo ""
echo "  ✅ ABRAMIA instalada correctamente!"
echo ""
echo "  Comandos disponibles:"
echo "    ai          Chat interactivo inteligente"
echo "    a \"texto\"   Pregunta directa"
echo ""
echo "  Configuración:"
echo "    Servidor: $SERVER"
echo "    Memoria:  ~/.abramia/"
echo ""
