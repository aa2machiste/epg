═══════════════════════════════════════════════════════════
🔮 ABRAMIA v5.0 - Backup Completo
═══════════════════════════════════════════════════════════

CONTENIDO:
  - ai           → Chat interactivo REFLEXIVO con memoria
  - a            → Pregunta directa
  - instalar.sh  → Instalador automático
  - .abramia/    → Memoria y logs
  - windows/     → Versión Windows

NOVEDADES v5.0:
  ✅ Metodología: Piensa → Ejecuta → Verifica
  ✅ Máximo 3 reintentos (no loops infinitos)
  ✅ Fuerza reflexión [PENSAR] antes de corregir errores
  ✅ Para y pregunta si no puede resolver
  ✅ 11 modelos con balanceo automático

INSTALACIÓN EN OTRA PC:
  1. Copia esta carpeta a la nueva PC
  2. Edita instalar.sh y cambia:
     - SERVER="http://IP_DEL_SERVIDOR:3000"
     - API_KEY="tu-api-key"
  3. Ejecuta: sudo bash instalar.sh

USO:
  ai              → Inicia chat interactivo
  a "pregunta"    → Pregunta rápida
  
DENTRO DE AI:
  salir           → Guardar y salir
  limpiar         → Borrar memoria
  estado          → Ver Docker, RAM, disco
  log             → Ver últimos comandos
  !comando        → Ejecutar comando directo

MODELOS (en orden de prioridad):
  1. gpt-4o
  2. gpt-4o-mini
  3. Meta-Llama-3.1-405B-Instruct
  4. ai/llama3.2:latest
  5. ai/gemma3:1B-F16
  6. ai/smollm2:360M-F16
  7. abramiagpt4-o
  8. github-gpt-4o-mini
  9. abramia:programador
  10. abramia-local-1o
  11. docker-gordon

═══════════════════════════════════════════════════════════
